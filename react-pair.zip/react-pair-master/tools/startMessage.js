import colors from 'colors';

console.log("starting app in dev mode...".blue);