# Code Pair

A React + Redux app that uses Express and Socket.io to implement real-time pair programming on code challenges. 

*Code challenges courtesty of [Project Euler](https://projecteuler.net/)* 

* Learn more about the project in this my blog post on Socket.io + React [here](http://www.thegreatcodeadventure.com/real-time-react-with-socket-io-building-a-pair-programming-app/).

